//  U34A1Q4
//  Ms.Harris
//  ICS4UI
//  Guanyu
//  2019.5.20
// borrow idea about read xml file from the website you gave us()can't remember which one
package com.example.u34a1q5;

import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends AppCompatActivity {
    InputStream xmlFile = null;
    ArrayList<Integer> numberList = new ArrayList<>();
    ArrayList<Integer> answerArray = new ArrayList<>();
    String numberlist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Readxml();//read in xml file
        TextView tv =(TextView)findViewById(R.id.introductionText);
        tv.setText("This program is for calculating your lucky number\nPlease input your birthday below" +
                "\nThis program will read in an xml file which contains lots of integer, and then sort them from small to big in a list." +
                "\nIt will choose the number which locates on the place of the number of your birth month and birth date in that list as the two number of fibonacci number." +
                "\nThe lucky number will be the fibonacci number locates on the sum of you birth year place");//set instruction text
        answerArray.add(numberList.get(0));
        //get number from numberlist one by one and call sort function
        for (int i = 1; i<numberList.size(); i++){
            answerArray.add(numberList.get(i));
            sort(answerArray);
        }
    }
    //function for read xml file
    public void Readxml(){
        AssetManager assetManager = getAssets();
        try {
            xmlFile = assetManager.open("data.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            NodeList nums = doc.getElementsByTagName("num");
            for(int i = 0; i < nums.getLength(); i++) {
                Node num = (Element) nums.item(i);
                numberList.add(Integer.valueOf(num.getTextContent()));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    //function for sorting list
    public void sort(ArrayList<Integer> unsortedArray){
        int firstNum;
        int secondNum;
        Boolean finish = false;
        int pos = unsortedArray.size()-1;
        while(pos != 0 && unsortedArray.get(pos) < unsortedArray.get(pos-1) && !finish){
            firstNum = unsortedArray.get(pos);
            secondNum = unsortedArray.get(pos-1);
            unsortedArray.set(pos,secondNum) ;
            unsortedArray.set(pos-1,firstNum) ;
            pos = pos-1;
        }
    }
    //function for fibonacci number
    public static int fibonacci(int num1, int num2, int count, int sum, int limit ){
        if(count < limit-2){
            sum = num1 + num2;
            count += 1;
            return fibonacci(num2,sum,count,sum,limit);
        }
        else{
            return sum;
        }

    }
    //function for action listener
    public void onClick(View view) {
        if(R.id.button == view.getId()) {
            //get text from EditText
            EditText yearText = (EditText) findViewById(R.id.yearText);
            String year = yearText.getText().toString();
            EditText monthText = (EditText) findViewById(R.id.monthText);
            String month = monthText.getText().toString();
            EditText dateText = (EditText) findViewById(R.id.dateText);
            String date = dateText.getText().toString();
            int limit = Integer.valueOf(year.substring(0, 1)) + Integer.valueOf(year.substring(1, 2)) + Integer.valueOf(year.substring(2, 3)) + Integer.valueOf(year.substring(3, 4));//calculate the sum of the number of birth year
            TextView tv =(TextView)findViewById(R.id.introductionText);
            for (int i = 0;i < answerArray.size();i++){
                numberlist += String.valueOf(answerArray.get(i)) + " ";
            }
            tv.setText("The sorted number list is:"+ numberlist +"\nThe first number of fibonacci is " + String.valueOf(answerArray.get(Integer.valueOf(month))) + "\nThe second fibonacci number is " + String.valueOf(answerArray.get(Integer.valueOf(date))) + "\nThe sum of your birth year is " + limit + "\nYour 'lucky' number is " +
                    String.valueOf(fibonacci(answerArray.get(Integer.valueOf(month)-1), answerArray.get(Integer.valueOf(date)-1), 0, 0, limit)));
        }
    }
}
