package com.example.n34a1q1;
//function for storing java object of station data
public class Station {
    String meanTemperature;
    String differenceFromNormal;
    String daysWithoutValidMeanTemperature;
    String maxTemperature;
    String daysWithoutValidMaxTemperature;
    String minTemperature;
    String daysWithoutValidMinTemperature;
    String snowfall;
    String percentOfNormalSnowfall;
    String snowOnTheGround;
    String daysWithoutValidSnowfall;
    String totalPrecipitation;
    String percentOfNormalPrecipitation;
    String daysWithoutValidPrecipitation;
    String numberOfDaysWithPrecipitation;
    String percentOfNormalBrightSunshine;
    String heatingDegreedays;
    String coolingDegreedays;
    public Station(String meanTemperature, String differenceFromNormal, String daysWithoutValidMeanTemperature,
                   String maxTemperature, String daysWithoutValidMaxTemperature, String minTemperature,
                   String daysWithoutValidMinTemperature, String snowfall, String percentOfNormalSnowfall,
                   String snowOnTheGround, String daysWithoutValidSnowfall, String totalPrecipitation,
                   String percentOfNormalPrecipitation, String daysWithoutValidPrecipitation,
                   String numberOfDaysWithPrecipitation, String percentOfNormalBrightSunshine,
                   String heatingDegreedays, String coolingDegreedays) {
        this.meanTemperature = meanTemperature;
        this.differenceFromNormal = differenceFromNormal;
        this.daysWithoutValidMeanTemperature = daysWithoutValidMeanTemperature;
        this.maxTemperature = maxTemperature;
        this.daysWithoutValidMaxTemperature = daysWithoutValidMaxTemperature;
        this.minTemperature = minTemperature;
        this.daysWithoutValidMinTemperature = daysWithoutValidMinTemperature;
        this.snowfall = snowfall;
        this.percentOfNormalSnowfall = percentOfNormalSnowfall;
        this.snowOnTheGround = snowOnTheGround;
        this.daysWithoutValidSnowfall = daysWithoutValidSnowfall;
        this.totalPrecipitation = totalPrecipitation;
        this.percentOfNormalPrecipitation = percentOfNormalPrecipitation;
        this.daysWithoutValidPrecipitation = daysWithoutValidPrecipitation;
        this.numberOfDaysWithPrecipitation = numberOfDaysWithPrecipitation;
        this.percentOfNormalBrightSunshine = percentOfNormalBrightSunshine;
        this.heatingDegreedays = heatingDegreedays;
        this.coolingDegreedays = coolingDegreedays;
    }
}
