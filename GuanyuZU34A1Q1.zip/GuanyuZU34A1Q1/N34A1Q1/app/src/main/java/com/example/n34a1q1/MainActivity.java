//  U34A1Q4
//  Ms.Harris
//  ICS4UI
//  Guanyu
//  2019.5.13
// borrow idea about read xml file from the website you gave us()can't remember which one
package com.example.n34a1q1;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends AppCompatActivity {

    public boolean bool_province = false;
    public boolean bool_station = false;
    String province = "";
    String station;
    String info;
    String answer;
    Double averageMeanTemprature = 0.0;
    Double averageDaysWithoutValidMeanTemperature = 0.0;
    Double averageMaxTemperature = 0.0;
    Double averageDaysWithoutValidMaxTemperature = 0.0;
    Double averageMinTemperature = 0.0;
    Double averageDaysWithoutValidMinTemperature = 0.0;
    Double averageSnowfall = 0.0;
    Double averageNumberOfDaysWithPrecipitation = 0.0;
    Double averageHeatingDegreedays = 0.0;
    Double averageCoolingDegreedays = 0.0;
    Double averageDaysWithoutValidSnowfall = 0.0;
    int count = 0;
    HashMap<String, HashMap<String, ArrayList<Station>>> data;
    //function of action listener
    public void onClick(View view) {
    TextView tv = findViewById(R.id.textView);
    if (view.getId() == R.id.startButton) {//check if user press start button
        //do all the work to start
        findViewById(R.id.startButton).setVisibility(View.INVISIBLE);
        tv.setText("Please type in the code of the province you want to know and then click 'ok'");
        findViewById(R.id.editText).setVisibility(view.VISIBLE);
        findViewById(R.id.okButton).setVisibility(View.VISIBLE);
    }
    else if (view.getId() == R.id.okButton && bool_province == false){//check if user press ok button for the first time
        province = ((TextView)findViewById(R.id.editText)).getText().toString();
        //give different respond for different situation
        if (!data.containsKey(province)){
            tv.setText("Sorry, we can't find the province you provide. Please try again");
        }
        else{
            bool_province = true;
            tv.setText("Please type in the city name or click summary or click the summary button to check the summary");
            findViewById(R.id.summaryButton).setVisibility(View.VISIBLE);
        }
    }
    else if (view.getId() == R.id.okButton && bool_province == true && bool_station == false){//check if user press ok for the second time
        //give different respond for different situation
        station = ((TextView)findViewById(R.id.editText)).getText().toString();
        if (!data.get(province).containsKey(station)){
            tv.setText("Sorry, we can't find the station you provide. Please try again");
        }
        else{
            bool_station = true;
            tv.setMovementMethod(new ScrollingMovementMethod());
            tv.setText("Please type in the code of information you want to get(for example Tm) or type in the word 'all' to get all the weather information of that station\n***The text can be scrolled down***\nTm:Mean Temperature\nDwTm:Days without Valid Mean Temperature\n" +
                    "D:Mean Temperature difference from Normal (1981-2010) (°C)\nTx:Highest Monthly Maximum Temperature\n" +
                    "DwTx:Days without Valid Maximum Temperature\nTn:Lowest Monthly Minimum Temperature (°C)\n" +
                    "DwTn:Days without Valid Minimum Temperature\nS:Snowfall(cm)\nDwS:Days without Valid Snowfall\n" +
                    "S%N:Percent of Normal (1981-2010) Snowfall\nP:Total Precipitation (mm)\nDwP:Days without Valid Precipitation\n" +
                    "P%N:Percent of Normal (1981-2010) Precipitation\nS_G:Snow on the ground at the end of the month (cm)v\n" +
                    "Pd:Number of days with Precipitation 1.0 mm or more\n + BS%:Percent of Normal (1981-2010) Bright Sunshine\n" +
                    "HDD:Degree Days below 18 °C\nCDD:Degree Days above 18 °C");
            findViewById(R.id.summaryButton).setVisibility(View.INVISIBLE);
        }
    }
    else if (view.getId() == R.id.restartButton) {//check if user press restart button
        //do work for restart
        tv.setText("This is a weather information app. Click the start button and follow the instruction can get the weather information.press restart to restart the app");
        findViewById(R.id.startButton).setVisibility(View.VISIBLE);
        findViewById(R.id.restartButton).setVisibility(View.INVISIBLE);
        findViewById(R.id.okButton).setVisibility(View.INVISIBLE);
        findViewById(R.id.editText).setVisibility(View.INVISIBLE);
        findViewById(R.id.summaryButton).setVisibility(View.INVISIBLE);
        province = "";
        station = "";
        bool_station = false;
        bool_province = false;
        count = 0;
    }
    else if (view.getId() == R.id.summaryButton) {//check if user press summary button
        findViewById(R.id.okButton).setVisibility(View.INVISIBLE);
        //calculate the average value of each section of weather information
        for (String stations : data.get(province).keySet()) {
            for (int l=0 ; l < data.get(province).get(stations).size();l++){
                if(l == 1){
                    count += 1;
                }
                if (data.get(province).get(stations).get(l).meanTemperature == ""){
                    averageMeanTemprature += 0;
                }
                if (data.get(province).get(stations).get(l).meanTemperature != "") {
                    averageMeanTemprature += Double.valueOf(data.get(province).get(stations).get(l).meanTemperature);
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidMeanTemperature == ""){
                    averageDaysWithoutValidMeanTemperature += 0;
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidMeanTemperature != ""){
                    averageDaysWithoutValidMeanTemperature += Double.valueOf(data.get(province).get(stations).get(l).daysWithoutValidMeanTemperature);
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidMinTemperature == ""){
                    averageDaysWithoutValidMinTemperature += 0;
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidMinTemperature != ""){
                    averageDaysWithoutValidMinTemperature += Double.valueOf(data.get(province).get(stations).get(l).daysWithoutValidMinTemperature);
                }
                if (data.get(province).get(stations).get(l).maxTemperature == ""){
                    averageMaxTemperature += 0;
                }
                if (data.get(province).get(stations).get(l).maxTemperature != ""){
                    averageMaxTemperature += Double.valueOf(data.get(province).get(stations).get(l).maxTemperature);
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidMaxTemperature == ""){
                    averageDaysWithoutValidMaxTemperature += 0;
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidMaxTemperature != ""){
                    averageDaysWithoutValidMaxTemperature += Double.valueOf(data.get(province).get(stations).get(l).daysWithoutValidMaxTemperature);
                }
                if (data.get(province).get(stations).get(l).minTemperature == ""){
                    averageMinTemperature += 0;
                }
                if (data.get(province).get(stations).get(l).minTemperature != ""){
                    averageMinTemperature += Double.valueOf(data.get(province).get(stations).get(l).minTemperature);
                }
                if (data.get(province).get(stations).get(l).snowfall == ""){
                    averageSnowfall += 0;
                }
                if (data.get(province).get(stations).get(l).snowfall != ""){
                    averageSnowfall += Double.valueOf(data.get(province).get(stations).get(l).snowfall);
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidSnowfall == ""){
                    averageDaysWithoutValidSnowfall += 0;
                }
                if (data.get(province).get(stations).get(l).daysWithoutValidSnowfall != ""){
                    averageDaysWithoutValidSnowfall += Double.valueOf(data.get(province).get(stations).get(l).daysWithoutValidSnowfall);
                }
                if (data.get(province).get(stations).get(l).numberOfDaysWithPrecipitation == ""){
                    averageNumberOfDaysWithPrecipitation += 0;
                }
                if (data.get(province).get(stations).get(l).numberOfDaysWithPrecipitation != ""){
                    averageNumberOfDaysWithPrecipitation += Double.valueOf(data.get(province).get(stations).get(l).numberOfDaysWithPrecipitation);
                }
                if (data.get(province).get(stations).get(l).coolingDegreedays == ""){
                    averageCoolingDegreedays += 0;
                }
                if (data.get(province).get(stations).get(l).coolingDegreedays != ""){
                    averageCoolingDegreedays += Double.valueOf(data.get(province).get(stations).get(l).coolingDegreedays);
                }
                if (data.get(province).get(stations).get(l).heatingDegreedays == ""){
                    averageHeatingDegreedays += 0;
                }
                if (data.get(province).get(stations).get(l).heatingDegreedays != ""){
                    averageHeatingDegreedays += Double.valueOf(data.get(province).get(stations).get(l).heatingDegreedays);
                }

            }
        }
        averageMeanTemprature = averageMeanTemprature/(data.get(province).size() + count);
        averageDaysWithoutValidMeanTemperature = averageDaysWithoutValidMeanTemperature/(data.get(province).size() + count);
        averageDaysWithoutValidMinTemperature = averageDaysWithoutValidMinTemperature/(data.get(province).size() + count);
        averageMaxTemperature = averageMaxTemperature/(data.get(province).size() + count);
        averageDaysWithoutValidMaxTemperature = averageDaysWithoutValidMaxTemperature/(data.get(province).size() + count);
        averageMinTemperature = averageMinTemperature/(data.get(province).size() + count);
        averageSnowfall = averageSnowfall/(data.get(province).size() + count);
        averageDaysWithoutValidSnowfall = averageDaysWithoutValidSnowfall/(data.get(province).size() + count);
        averageNumberOfDaysWithPrecipitation = averageNumberOfDaysWithPrecipitation/(data.get(province).size() + count);
        averageCoolingDegreedays = averageCoolingDegreedays/(data.get(province).size() + count);
        averageHeatingDegreedays = averageHeatingDegreedays/(data.get(province).size() + count);
        tv.setMovementMethod(new ScrollingMovementMethod());
        tv.setText("The average mean temperature of this province is " + averageMeanTemprature.toString() +
                "\nThe average days without valid mean temperature is " + averageDaysWithoutValidMeanTemperature.toString() +
                "\nThe average days without valid minimum temperature is " + averageDaysWithoutValidMinTemperature.toString() +
                "\nThe average max temperature is " + averageMaxTemperature.toString() +
                "\nThe average days without valid max temperature is " + averageDaysWithoutValidMaxTemperature.toString() +
                "\nThe average minimum temperature is " + averageMinTemperature.toString() +
                "\nThe average snow fall is " + averageSnowfall.toString() + " cm" +
                "\nThe average days without valid snowfall is " + averageDaysWithoutValidSnowfall.toString() +
                "\nThe average number of days with precipitation is " + averageNumberOfDaysWithPrecipitation.toString() +
                "\nThe average cooling degree days is " + averageCoolingDegreedays.toString() +
                "\nThe average heating degree days is " + averageHeatingDegreedays.toString());
        findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
    }
    else if (view.getId() == R.id.okButton && bool_province == true && bool_station == true) {//check if user press ok button for the second time.
        //give instruction for next step
        info = ((TextView) findViewById(R.id.editText)).getText().toString();
        if(info != "all" && info != "Tm" && info != "DwTm" && info != "D" && info != "Tx" && info != "DwTx" && info != "Tn" && info != "DwTn" && info != "S" &&info != "DwS" &&info != "S%N" &&info != "P" &&info != "DwP" && info != "P%N" && info != "S_G" &&info != "Pd" &&info != "BS%" &&info != "HDD" && info != "CDD"){
            tv.setText("Sorry, please check your spell and follow the instruction please." + "\nPlease type in the code of information you want to get(for example Tm) or type in the word 'all' to get all the weather information of that station\n***The text can be scrolled down***\nTm:Mean Temperature\nDwTm:Days without Valid Mean Temperature\n" +
                    "D:Mean Temperature difference from Normal (1981-2010) (°C)\nTx:Highest Monthly Maximum Temperature\n" + "DwTx:Days without Valid Maximum Temperature\nTn:Lowest Monthly Minimum Temperature (°C)\n" +
                    "DwTn:Days without Valid Minimum Temperature\nS:Snowfall(cm)\nDwS:Days without Valid Snowfall\n" + "S%N:Percent of Normal (1981-2010) Snowfall\nP:Total Precipitation (mm)\nDwP:Days without Valid Precipitation\n" +
                    "P%N:Percent of Normal (1981-2010) Precipitation\nS_G:Snow on the ground at the end of the month (cm)v\n" +
                    "Pd:Number of days with Precipitation 1.0 mm or more\n + BS%:Percent of Normal (1981-2010) Bright Sunshine\n" +
                    "HDD:Degree Days below 18 °C\nCDD:Degree Days above 18 °C");
        }
        //give different results depending on different request
        switch (info){
            case "all":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "Tm: "+data.get(province).get(station).get(k).meanTemperature + "\nDwTm: " + data.get(province).get(station).get(k).daysWithoutValidMeanTemperature
                    + "\nD: " + data.get(province).get(station).get(k).differenceFromNormal + "\nTx: " + data.get(province).get(station).get(k).maxTemperature +
                            "\nDwTx: " + data.get(province).get(station).get(k).daysWithoutValidMaxTemperature + "\nTn: " + data.get(province).get(station).get(k).minTemperature +
                            "\nDwTn: " + data.get(province).get(station).get(k).daysWithoutValidMinTemperature + "\nS: " + data.get(province).get(station).get(k).snowfall +
                            "\nDwS: " + data.get(province).get(station).get(k).daysWithoutValidSnowfall + "\nS%N: " + data.get(province).get(station).get(k).percentOfNormalSnowfall +
                            "\nP: " + data.get(province).get(station).get(k).totalPrecipitation + "\nDwP: " + data.get(province).get(station).get(k).daysWithoutValidPrecipitation +
                            "\nP%N: " + data.get(province).get(station).get(k).percentOfNormalPrecipitation + "\nS_G: " + data.get(province).get(station).get(k).snowOnTheGround +
                            "\nPd: " + data.get(province).get(station).get(k).numberOfDaysWithPrecipitation + "\nBS%: " + data.get(province).get(station).get(k).percentOfNormalBrightSunshine +
                            "\nHDD: " + data.get(province).get(station).get(k).coolingDegreedays + "\nCDD: " + data.get(province).get(station).get(k).heatingDegreedays;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "Tm":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "Tm: "+data.get(province).get(station).get(k).meanTemperature;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "DwTm":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "DwTm: "+data.get(province).get(station).get(k).daysWithoutValidMeanTemperature;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "D":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "D: "+data.get(province).get(station).get(k).differenceFromNormal;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "Tx":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "Tx: "+data.get(province).get(station).get(k).maxTemperature;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "DwTx":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "DwTx: "+data.get(province).get(station).get(k).daysWithoutValidMaxTemperature;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "Tn":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "Tn: "+data.get(province).get(station).get(k).minTemperature;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "DwTn":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "DwTn: "+data.get(province).get(station).get(k).daysWithoutValidMinTemperature;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "S":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "S: "+data.get(province).get(station).get(k).snowfall;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "DwS":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "DwS: "+data.get(province).get(station).get(k).daysWithoutValidSnowfall;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "S%N":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "S%N: "+data.get(province).get(station).get(k).percentOfNormalSnowfall;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "P":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "P: "+data.get(province).get(station).get(k).totalPrecipitation;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "DwP":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "DwP: "+data.get(province).get(station).get(k).daysWithoutValidPrecipitation;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "P%N":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "P%N: "+data.get(province).get(station).get(k).percentOfNormalPrecipitation;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "S_G":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "S_G: "+data.get(province).get(station).get(k).snowOnTheGround;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "Pd":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "Pd: "+data.get(province).get(station).get(k).numberOfDaysWithPrecipitation;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "BS%":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "BS%: "+data.get(province).get(station).get(k).percentOfNormalBrightSunshine;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "HDD":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "HDD: "+data.get(province).get(station).get(k).coolingDegreedays;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;
            case "CDD":
                for (int k=0;k<data.get(province).get(station).size();k++){
                    answer += "CDD: "+data.get(province).get(station).get(k).heatingDegreedays;
                }
                tv.setText(answer);
                findViewById(R.id.restartButton).setVisibility(View.VISIBLE);
                break;

        }
    }
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        convertXmlToObjects();
    }
    private void convertXmlToObjects() {
        data = new HashMap<>();

        AssetManager assetManager = getAssets();
    //read xml file
        try {
            InputStream xmlFile = assetManager.open("climate-summaries.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);

            doc.getDocumentElement().normalize();

            NodeList stationTags = doc.getElementsByTagName("station");

            for (int i = 0; i < stationTags.getLength(); ++i) {
                Node stationTag = stationTags.item(i);

                if (stationTag.getNodeType() == Node.ELEMENT_NODE) {
                    Element stationElement = (Element) stationTag;

                    Station station = new Station(
                            getAttribute(stationElement, "mean_temperature", "value"),
                            getAttribute(stationElement, "mean_temperature", "differencefromnormal"),
                            getAttribute(stationElement, "mean_temperature", "dayswithoutvalidmeasure"),
                            getAttribute(stationElement, "max_temperature", "value"),
                            getAttribute(stationElement, "max_temperature", "dayswithoutvalidmeasure"),
                            getAttribute(stationElement, "min_temperature", "value"),
                            getAttribute(stationElement, "min_temperature", "dayswithoutvalidmeasure"),
                            getAttribute(stationElement, "snow", "total"),
                            getAttribute(stationElement, "snow", "percentofnormal"),
                            getAttribute(stationElement, "snow", "onground"),
                            getAttribute(stationElement, "snow", "dayswithoutvalidmeasure"),
                            getAttribute(stationElement, "precipitation", "total"),
                            getAttribute(stationElement, "precipitation", "percentofnormal"),
                            getAttribute(stationElement, "precipitation", "dayswithoutvalidmeasure"),
                            getAttribute(stationElement, "precipitation", "dayswith"),
                            getAttribute(stationElement, "sunshine", "percentofnormal"),
                            getAttribute(stationElement, "degreedays", "heating"),
                            getAttribute(stationElement, "degreedays", "cooling")
                    );

                    String province = getAttribute(stationElement, "province", "code");
                    String stationName = getContent(stationElement, "name");

                    if (!data.containsKey(province)) {
                        data.put(province, new HashMap<String, ArrayList<Station>>());
                    }

                    if (!data.get(province).containsKey(stationName)) {
                        data.get(province).put(stationName, new ArrayList<Station>());
                    }

                    data.get(province).get(stationName).add(station);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //function for get content from xml file
    private String getContent(Element stationElement, String nodeName) {
        return stationElement.getElementsByTagName(nodeName).item(0).getTextContent();
    }
    //function for get attribute from xml file
    private String getAttribute(Element stationElement, String nodeName, String key) {
        Node node = stationElement.getElementsByTagName(nodeName).item(0);
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            return element.getAttribute(key);
        }
        return "";
    }
}
