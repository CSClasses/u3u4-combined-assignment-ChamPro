package com.example.n34a1q1;

import android.app.Service;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class XmlImport extends Service {
    // province -> (station_name -> list of station stats)
    HashMap<String, HashMap<String, ArrayList<Station>>> data;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        convertXmlToObjects();
        sendData();
        return START_NOT_STICKY;
    }

    private void convertXmlToObjects() {
        data = new HashMap<>();

        AssetManager assetManager = getAssets();

        try {
            InputStream xmlFile = assetManager.open("climate-summaries.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);

            doc.getDocumentElement().normalize();

            NodeList stationTags = doc.getElementsByTagName("station");

            for (int i = 0; i < stationTags.getLength(); ++i) {
                Node stationTag = stationTags.item(i);

                if (stationTag.getNodeType() == Node.ELEMENT_NODE) {
                    Element stationElement = (Element) stationTag;

                    Station station = new Station(
                        getAttribute(stationElement, "mean_temperature", "value"),
                        getAttribute(stationElement, "mean_temperature", "differencefromnormal"),
                        getAttribute(stationElement, "mean_temperature", "dayswithoutvalidmeasure"),
                        getAttribute(stationElement, "max_temperature", "value"),
                        getAttribute(stationElement, "max_temperature", "dayswithoutvalidmeasure"),
                        getAttribute(stationElement, "min_temperature", "value"),
                        getAttribute(stationElement, "min_temperature", "dayswithoutvalidmeasure"),
                        getAttribute(stationElement, "snow", "total"),
                        getAttribute(stationElement, "snow", "percentofnormal"),
                        getAttribute(stationElement, "snow", "onground"),
                        getAttribute(stationElement, "snow", "dayswithoutvalidmeasure"),
                        getAttribute(stationElement, "precipitation", "total"),
                        getAttribute(stationElement, "precipitation", "percentofnormal"),
                        getAttribute(stationElement, "precipitation", "dayswithoutvalidmeasure"),
                        getAttribute(stationElement, "precipitation", "dayswith"),
                        getAttribute(stationElement, "sunshine", "percentofnormal"),
                        getAttribute(stationElement, "degreedays", "heating"),
                        getAttribute(stationElement, "degreedays", "cooling")
                    );

                    String province = getAttribute(stationElement, "province", "code");
                    String stationName = getContent(stationElement, "name");

                    if (!data.containsKey(province)) {
                        data.put(province, new HashMap<String, ArrayList<Station>>());
                    }

                    if (!data.get(province).containsKey(stationName)) {
                        data.get(province).put(stationName, new ArrayList<Station>());
                    }

                    data.get(province).get(stationName).add(station);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getContent(Element stationElement, String nodeName) {
        return stationElement.getElementsByTagName(nodeName).item(0).getTextContent();
    }

    private String getAttribute(Element stationElement, String nodeName, String key) {
        Node node = stationElement.getElementsByTagName(nodeName).item(0);
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            return element.getAttribute(key);
        }
        return "";
    }

    private void sendData() {
        Intent intent = new Intent("xml");
        intent.putExtra("data", data);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
