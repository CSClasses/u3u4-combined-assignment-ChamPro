//  U34A1Q4
//  Ms.Harris
//  ICS4UI
//  Guanyu
//  2019.5.13
package com.example.u34a1q3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Boolean clickCustomButton = false;
    String result = "";
    Boolean clickEqualButton = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClick(View view) {
        TextView tv = findViewById(R.id.textView);
        TextView tiptv = findViewById(R.id.textView5);
        TextView totaltv = findViewById(R.id.textView6);
        TextView percenttv = findViewById(R.id.textView7);
        String original = tv.getText().toString();
        String tiporiginal = tiptv.getText().toString();
        //display the number which user choose on the screen
        switch (view.getId()) {
            case R.id.button1:
                if(!clickCustomButton) {
                    result = original + "1";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "1";
                    tiptv.setText(result);
                }
                break;
            case R.id.button2:
                if(!clickCustomButton) {
                    result = original + "2";
                    tv.setText(result);
                }
                else{
                    result = tiporiginal + "2";
                    tiptv.setText(result);
                }
                break;
            case R.id.button3:
                if(!clickCustomButton) {
                    result = original + "3";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "3";
                    tiptv.setText(result);
                }
                break;
            case R.id.button4:
                if(!clickCustomButton) {
                    result = original + "4";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "4";
                    tiptv.setText(result);
                }
                break;
            case R.id.button5:
                if(!clickCustomButton) {
                    result = original + "5";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "5";
                    tiptv.setText(result);
                }
                break;
            case R.id.button6:
                if(!clickCustomButton) {
                    result = original + "6";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "6";
                    tiptv.setText(result);
                }
                break;
            case R.id.button7:
                if(!clickCustomButton) {
                    result = original + "7";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "7";
                    tiptv.setText(result);
                }
                break;
            case R.id.button8:
                if(!clickCustomButton) {
                    result = original + "8";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "8";
                    tiptv.setText(result);
                }
                break;
            case R.id.button9:
                if(!clickCustomButton) {
                    result = original + "9";
                    tv.setText(result);
                }
                else{
                    result = tiporiginal + "9";
                    tiptv.setText(result);
                }
                break;
            case R.id.button0:
                if(!clickCustomButton) {
                    result = original + "0";
                    tv.setText(result);
                }
                else{
                    result =tiporiginal + "0";
                    tiptv.setText(result);
                }
                break;
            case R.id.pointButton://check is user click the point button
                if(clickCustomButton && !clickEqualButton) {
                    result = tiporiginal + ".";
                    tiptv.setText(result);
                }
                else if (!clickCustomButton && !clickEqualButton){
                    result = original + ".";
                    tv.setText(result);
                    }
                break;
            case R.id.clearButton://check if user click clear button
                //clear everything
                result = "";
                tv.setText(result);
                tiptv.setText(result);
                totaltv.setText(result);
                percenttv.setText(result);
                clickCustomButton = false;
                clickEqualButton = false;
                break;
            case R.id.button15tip://check if user click the 15 percent tip button
                //if there is nothing on textview then take it as 0
                if (original == ""){
                    tv.setText("0");
                    tiptv.setText("0");
                }
                //if there is something on textview then calculate it
                else{
                    result = String.format("%.2f", Double.valueOf(original)*0.15);
                    tiptv.setText(result);
                }
                break;
            case R.id.custom://check if user click custom button
                percenttv.setText("%");
                if(original != "") {
                    clickCustomButton = true;
                }
                break;
            case R.id.backButton://check if user click back button
                //if there is something on textview then calculate it
                if (clickCustomButton && tiptv.getText().toString().length() > 1){
                    result = tiptv.getText().toString().substring(0,original.length() - 1);
                    tiptv.setText(result);
                }
                //if there is nothing on textview then take it as 0
                else if (clickCustomButton && tiptv.getText().toString().length() == 1){
                    result = "0";
                    tiptv.setText(result);
                }
                //if there is something on textview then calculate it
                else if (!clickCustomButton && original.length() > 1 && !clickEqualButton ){
                    result = original.substring(0,original.length() - 1);
                    tv.setText(result);
                }
                //if there is nothing on textview then take it as 0
                else if (!clickCustomButton && original.length() == 1 && !clickEqualButton){
                    result = "0";
                    tv.setText(result);
                }
                break;
            case R.id.equalButton://check if user click equal button
                //if there is nothing on textview then take it as 0
                    if (original == ""){
                    tv.setText("0");
                    tiptv.setText("0");
                //if there is something on textview then calculate it
                }
                if(clickCustomButton){
                    result = String.format("%.2f", Double.valueOf(original) * Double.valueOf(tiporiginal)/100);
                    tiptv.setText(result);
                    percenttv.setText("");
                    clickCustomButton = false;
                }
                totaltv.setText(String.format("%.2f", Double.valueOf(tv.getText().toString())+Double.valueOf(tiptv.getText().toString())));
                clickEqualButton = true;
                break;
        }
    }
}
