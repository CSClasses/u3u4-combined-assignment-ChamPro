//
//  ViewController.swift
//  U34A1Q4
//  Ms.Harris
//  ICS4UI
//  Guanyu
//  2019.5.19
//  Created by 朱冠宇 on 2019/5/19.
//  Copyright © 2019年 朱冠宇. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var answerField: UITextField!
    @IBOutlet weak var questionText: UITextView!
    @IBOutlet weak var yesButton: UIButton!
    @IBOutlet weak var noButton: UIButton!
    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var up: UIButton!
    @IBOutlet weak var left: UIButton!
    @IBOutlet weak var right: UIButton!
    @IBOutlet weak var down: UIButton!
    @IBOutlet weak var exitButton: UIButton!
    @IBOutlet weak var leftImage: UIImageView!
    @IBOutlet weak var rightImage: UIImageView!
    @IBOutlet weak var upImage: UIImageView!
    @IBOutlet weak var downImage: UIImageView!
    let rightArrowImage: UIImage = UIImage(named: "rightArrow.png")!
    let leftArrowImage: UIImage = UIImage(named: "leftArrow.png")!
    let upArrowImage: UIImage = UIImage(named: "upArrow.png")!
    let downArrowImage: UIImage = UIImage(named: "downArrow.png")!
    override func viewDidLoad() {
        up.setImage(upArrowImage, for: .normal)
        left.setImage(leftArrowImage, for: .normal)
        right.setImage(rightArrowImage, for: .normal)
        down.setImage(downArrowImage, for: .normal)
        super.viewDidLoad()

    }
    //function for hide for arrow images
    func hideArrows(){
        up.isHidden = true
        down.isHidden = true
        left.isHidden = true
        right.isHidden = true
    }
    //function for going back
    func goback(){
        up.isHidden = false
        down.isHidden = false
        left.isHidden = false
        right.isHidden = false
        leftImage.isHidden = true
        exitButton.isHidden = true
        yesButton.isHidden = true
        noButton.isHidden = true
        questionText.isHidden = true
        answerField.isHidden = true
        rightImage.isHidden = true
        okButton.isHidden = true
        upImage.isHidden = true
        downImage.isHidden = true
    }
    @IBAction func pressLeftButton(_ sender: Any) {//check user click left arrow button
        //show question, answer button and image,hide others
        leftImage.isHidden = false
        questionText.isHidden = false
        exitButton.isHidden = false
        yesButton.isHidden = false
        noButton.isHidden = false
        hideArrows()
        questionText.text = "If you are given a chice, Do you want to be a left-handed person?"
    }
    @IBAction func pressUpButton(_ sender: Any) {//check user click up arrow button
        //check user click left arrow button
        //show question, answer button and image,hide others
        hideArrows()
        upImage.isHidden = false
        questionText.isHidden = false
        exitButton.isHidden = false
        yesButton.isHidden = false
        noButton.isHidden = false
        questionText.text = "Do you want to take a ride of hot air bullon?"
    }
    @IBAction func pressRightButton(_ sender: Any) {//check user click right arrow button
        //show question, answer button and image,hide others
        hideArrows()
        rightImage.isHidden = false
        questionText.isHidden = false
        answerField.isHidden = false
        exitButton.isHidden = false
        okButton.isHidden = false
        questionText.text = "Accrofing to the picture below, how many hours in a week poele can turn right legally?"
    }
    @IBAction func pressDownButton(_ sender: Any) {//check user click right arrow button
        //show question, answer button and image,hide others
        hideArrows()
        downImage.isHidden = false
        questionText.isHidden = false
        exitButton.isHidden = false
        yesButton.isHidden = false
        noButton.isHidden = false
        questionText.text = "Have you ever used a well to get water?"
    }
    @IBAction func pressYesButton(_ sender: Any) {//check if user click yes button
        goback()
    }
    @IBAction func pressNoButton(_ sender: Any) {//check if user click no button
        goback()
    }
    @IBAction func pressExitButton(_ sender: Any) {//check if user click exit button
        goback()
    }
    @IBAction func pressOkButton(_ sender: Any) {//
        //check if user click ok button
        let name:String = answerField.text!
        //check the answer of the quiz
        if (name == "148"){
            questionText.text = "Congratulations, your answer is right"
        }
        else{
            questionText.text = "Sorry, your answer is wrong. Please try again"
        }
    }
    

}

